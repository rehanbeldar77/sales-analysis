-- Mobile Sales Analysis - SQL practice templates
-- IMPORTANT: Replace table/column names to match your actual source dataset.
-- Suggested table name: sales_data

-- 1. Overall sales KPIs
SELECT
    SUM(total_sales) AS total_sales,
    SUM(quantity) AS total_quantity,
    COUNT(DISTINCT transaction_id) AS transactions,
    AVG(total_sales) AS average_sales_per_row
FROM sales_data;

-- 2. Sales by brand
SELECT brand, SUM(total_sales) AS total_sales
FROM sales_data
GROUP BY brand
ORDER BY total_sales DESC;

-- 3. Sales by mobile model
SELECT mobile_model, SUM(total_sales) AS total_sales
FROM sales_data
GROUP BY mobile_model
ORDER BY total_sales DESC;

-- 4. Sales by city
SELECT city, SUM(total_sales) AS total_sales
FROM sales_data
GROUP BY city
ORDER BY total_sales DESC;

-- 5. Transactions by payment method
SELECT payment_method, COUNT(DISTINCT transaction_id) AS transactions
FROM sales_data
GROUP BY payment_method
ORDER BY transactions DESC;

-- 6. Monthly sales trend (syntax may vary by database)
SELECT
    EXTRACT(YEAR FROM sale_date) AS sales_year,
    EXTRACT(MONTH FROM sale_date) AS sales_month,
    SUM(total_sales) AS total_sales
FROM sales_data
GROUP BY EXTRACT(YEAR FROM sale_date), EXTRACT(MONTH FROM sale_date)
ORDER BY sales_year, sales_month;

-- 7. Average customer rating by brand
SELECT brand, AVG(customer_ratings) AS average_rating
FROM sales_data
GROUP BY brand
ORDER BY average_rating DESC;
